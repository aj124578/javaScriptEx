import { useState } from "react";

function App() {

  const [user, setUser] = useState({
    username: "ssar",
    password: "1234"
  });

  const [list, setList] = useState([1,2,3,4,5]);

  function change(){
    setList([...list, 6]);
  }

  return(
      <div> 
      <button onClick={change}>값추가</button>
        {list.map((num) => <h1>{num}</h1>)}
      </div>
  )

  function changePassword() {
    setUser({
      username: "ssar",
      password: "5678"
    });
  }


  return (
    <div>
      <button onClick={changePassword}>패스워드변경</button>
      <table border="1">
        <tr>
          <td>유저이름</td>
          <td>패스워드</td>
        </tr>
        <tr>
          <td>{user.username}</td>
          <td>{user.password}</td>
        </tr>
      </table>
    </div>
  );
}

export default App;